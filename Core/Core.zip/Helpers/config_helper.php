<?php

function appKey_config(){
    return $GLOBALS['config']['app_key'];
}