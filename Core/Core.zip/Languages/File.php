<?php
    
$lang =  [
    'size_too_large' => "File Size is too Large",
    'extension_not_allowed' => "File Extension is not Allowed",
    
];