<?php
    
$lang =  [
    'could_not_add_list_type_of' => "Couldn't Add List Type of %s with %s",
    
];